package work.microhand.service;

import work.microhand.manager.GameManager;
import work.microhand.manager.GameSaveManager;
import work.microhand.model.game.SavedGame;
import work.microhand.view.game.GomokuGame;

import javax.swing.*;

public class ArchiveSelectService {
    public static void onClickLoadButton(SavedGame selectedArchive) {
        if (selectedArchive != null) {

            loadArchive(selectedArchive);
        } else {
            JOptionPane.showMessageDialog(null, "Invalid file");
        }
    }

    public static void onClickDeleteButton(DefaultListModel<SavedGame> archiveListModel, SavedGame selectedArchive) {
        if (selectedArchive != null) {

            deleteArchive(archiveListModel, selectedArchive);
        } else {
            JOptionPane.showMessageDialog(null, "Invalid file");
        }
    }

    private static void loadArchive(SavedGame archive) {

        GameManager.INSTANCE.loadGame(archive.getGame());
        JOptionPane.showMessageDialog(null, "Load archive" + archive.getSaveDate());
        GomokuGame.staticRepaint();
    }

    private static void deleteArchive(DefaultListModel<SavedGame> archiveListModel, SavedGame archive) {

        archiveListModel.removeElement(archive);
        GameSaveManager.INSTANCE.delete(archive);
        JOptionPane.showMessageDialog(null, "Delete archive" + archive);
    }
}
