package work.microhand.model.game;

public enum Player {
 
    WHITE('X'),
 
    BLACK('O');

    private char pieceSymbol;

    Player(char pieceSymbol) {
        this.pieceSymbol = pieceSymbol;
    }

    public char getPieceSymbol() {
        return pieceSymbol;
    }
}
