package work.microhand.view.archive;

import work.microhand.manager.GameSaveManager;
import work.microhand.model.game.SavedGame;
import work.microhand.service.ArchiveSelectService;

import javax.swing.*;
import java.awt.*;

public class ArchiveSelectionPage extends JFrame {
    private JList<SavedGame> archiveList;
    private DefaultListModel<SavedGame> archiveListModel;

    public ArchiveSelectionPage() {
        setTitle("Archive Selection");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initializes the archive list
        archiveListModel = new DefaultListModel<>();
        archiveListModel.addAll(GameSaveManager.INSTANCE.getSavedGames());
        archiveList = new JList<>(archiveListModel);
        JScrollPane scrollPane = new JScrollPane(archiveList);

        // Initialize the load button and delete button
        JButton loadButton = new JButton("Load archive");
        JButton deleteButton = new JButton("Delete archive");

        loadButton.addActionListener(e -> {
            SavedGame selectedArchive = archiveList.getSelectedValue();
            ArchiveSelectService.onClickLoadButton(selectedArchive);
        });

        deleteButton.addActionListener(e -> {
            SavedGame selectedArchive = archiveList.getSelectedValue();
            ArchiveSelectService.onClickDeleteButton(archiveListModel, selectedArchive);
        });

        // Layout interface
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(loadButton);
        buttonPanel.add(deleteButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }
}
