package work.microhand;

import org.junit.jupiter.api.Test;
import work.microhand.io.DataSource;

import java.sql.SQLException;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DataSourceTest {

    @Test
    public void testInitDatabase() {
        // Create a mock Properties object
        Properties properties = new Properties();
        properties.setProperty("druid.driverClassName", "org.apache.derby.jdbc.EmbeddedDriver");
        properties.setProperty("druid.url", "jdbc:derby:memory:testdb;create=true");

        DataSource dataSource = new DataSource(properties);

        // Verify that the database was successfully created
        assertTrue(dataSource.getDataSource().isEnable());
    }

    @Test
    public void testGetDataSource() {
        // Create a mock Properties object
        Properties properties = new Properties();
        properties.setProperty("druid.driverClassName", "org.apache.derby.jdbc.EmbeddedDriver");
        properties.setProperty("druid.url", "jdbc:derby:memory:testdb;create=true");

        DataSource dataSource = new DataSource(properties);

        // Verify that the returned data source object is not empty
        assertNotNull(dataSource.getDataSource());
    }

    @Test
    public void testGetConnection() throws SQLException {
        // Create a mock Properties object
        Properties properties = new Properties();
        properties.setProperty("druid.driverClassName", "org.apache.derby.jdbc.EmbeddedDriver");
        properties.setProperty("druid.url", "jdbc:derby:memory:testdb;create=true");

        DataSource dataSource = new DataSource(properties);

        // Verify that the returned data source object is not empty
        assertNotNull(dataSource.getConnection());
    }
}
